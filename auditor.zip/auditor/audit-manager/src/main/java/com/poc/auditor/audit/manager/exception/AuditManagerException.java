package com.poc.auditor.audit.manager.exception;

import java.io.Serializable;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Exception class for managing Audit-Service API errors.
 */
public class AuditManagerException extends Exception implements Serializable {

	private static final long serialVersionUID = -4873736688422645862L;

	public AuditManagerException() {
		super();
	}

	public AuditManagerException(String msg) {
		super(msg);
	}

	public AuditManagerException(String msg, Exception e) {
		super(msg, e);
	}
}
