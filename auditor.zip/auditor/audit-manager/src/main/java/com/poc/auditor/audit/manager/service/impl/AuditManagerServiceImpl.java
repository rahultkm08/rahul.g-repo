package com.poc.auditor.audit.manager.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.poc.auditor.audit.manager.component.AuditManagerComponent;
import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditResponseVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.exception.AuditManagerException;
import com.poc.auditor.audit.manager.service.AuditManagerService;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for managing Audit Data operations.
 */
public class AuditManagerServiceImpl implements AuditManagerService {

	@Autowired
	private AuditManagerComponent auditManagerComponent;
	
	public AuditManagerComponent getAuditManagerComponent() {
		return auditManagerComponent;
	}

	public void setAuditManagerComponent(AuditManagerComponent auditManagerComponent) {
		this.auditManagerComponent = auditManagerComponent;
	}

	public AuditResponseVO saveAuditEntry(AuditRequestVO requestVO) throws AuditManagerException {
		AuditResponseVO responseVO = new AuditResponseVO();
		responseVO.setStatus(auditManagerComponent.saveAuditEntry(requestVO));
		return responseVO;
	}

	public AuditResponseVO searchAuditEntry(AuditSearchVO requestVO) throws AuditManagerException {
		return auditManagerComponent.searchAuditEntry(requestVO);
	}

}
