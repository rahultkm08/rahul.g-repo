package com.poc.auditor.audit.manager.test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.dto.AuditServiceVO;
import com.poc.auditor.audit.manager.dto.AuditTransactionVO;

public class TestSearch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AuditSearchVO searchVO = new AuditSearchVO();

		Calendar c = Calendar.getInstance();
		searchVO.setToDate(c.getTime());
		c.add(Calendar.MINUTE, -130);
		c.set(Calendar.SECOND, 0);
		searchVO.setFromDate(c.getTime());

		List<AuditServiceVO> auditServiceVOs = new ArrayList<AuditServiceVO>();

		AuditServiceVO auditServiceVO = new AuditServiceVO();
		auditServiceVO.setServiceName("BOOKING");

		List<AuditTransactionVO> transactionVOs = new ArrayList<AuditTransactionVO>();
		AuditTransactionVO auditTransactionVO = new AuditTransactionVO();
		auditTransactionVO.setTransactionName("RECEIPT_TRANSACTION");
		transactionVOs.add(auditTransactionVO);
		auditTransactionVO = new AuditTransactionVO();
		auditTransactionVO.setTransactionName("ITEM_IMPORT");
		transactionVOs.add(auditTransactionVO);
		auditServiceVO.setTransactionVOs(transactionVOs);

		auditServiceVOs.add(auditServiceVO);

		searchVO.setAuditServiceVOs(auditServiceVOs);

		try {
			JAXBContext context;
			BufferedWriter writer = null;
			writer = new BufferedWriter(new FileWriter("audit-search.xml"));
			context = JAXBContext.newInstance(AuditSearchVO.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(searchVO, writer);
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
