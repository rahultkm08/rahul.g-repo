package com.poc.auditor.audit.manager.test;

import java.io.BufferedWriter;
import java.io.FileWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.poc.auditor.audit.manager.dto.AuditRequestVO;

public class Test {

	public static void main(String[] args) {

		try {
			AuditRequestVO auditRequestVO = new AuditRequestVO();
			auditRequestVO.setTenantId("Tenant1");
			auditRequestVO.setOperationName("RECEIPT_TRANSACTION");
			auditRequestVO.setSourceSystem("BOOKING");
			auditRequestVO.setTargetSystem("UDI");
			auditRequestVO.setReqPayload("reqPayload");
			auditRequestVO.setRespPayload("respPayload");
			JAXBContext context;
			BufferedWriter writer = null;
			writer = new BufferedWriter(new FileWriter("audit-request.xml"));
			context = JAXBContext.newInstance(AuditRequestVO.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(auditRequestVO, writer);
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
