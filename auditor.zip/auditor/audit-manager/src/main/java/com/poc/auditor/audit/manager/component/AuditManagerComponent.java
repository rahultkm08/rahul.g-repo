package com.poc.auditor.audit.manager.component;

import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditResponseVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.exception.AuditManagerException;

public interface AuditManagerComponent {

	public Boolean saveAuditEntry(AuditRequestVO requestVO) throws AuditManagerException;
	
	public AuditResponseVO searchAuditEntry(AuditSearchVO searchVO) throws AuditManagerException;
}
