package com.poc.auditor.audit.manager.test;

import java.util.Calendar;

public class TestCalenderTime {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println(Calendar.getInstance().get(Calendar.MINUTE));
		//System.out.println(Calendar.MINUTE);
		Calendar c = Calendar.getInstance();
		//c.add(c.get(Calendar.MINUTE), (Calendar.getInstance().get(Calendar.MINUTE) - 25));
		//c.set(Calendar.HOUR, (Calendar.getInstance().get(Calendar.MINUTE - 25)));
		
		System.out.println(c.getTime());
		c.add(Calendar.MINUTE, -130);
		c.set(Calendar.SECOND, 0);
		//c.add(Calendar.HOUR, -1);
		System.out.println(c.getTime());
		
	}

}
