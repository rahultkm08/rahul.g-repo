package com.poc.auditor.audit.manager.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditResponseVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.exception.AuditManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for managing Audit Data operations.
 */
@Component
@Path("/audit-data")
public interface AuditManagerService {

	@POST
	@Path("/saveAudit")
	@Consumes({MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_XML})
	public AuditResponseVO saveAuditEntry(AuditRequestVO requestVO) throws AuditManagerException;
	
	@POST
	@Path("/searchAudit")
	@Consumes({MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_XML})
	public AuditResponseVO searchAuditEntry(AuditSearchVO requestVO) throws AuditManagerException;
}

