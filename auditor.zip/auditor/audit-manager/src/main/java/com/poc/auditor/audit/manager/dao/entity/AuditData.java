package com.poc.auditor.audit.manager.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Audit Data.
 */
@Entity
@Table(name = "AUDT_AUDIT_MNGR")
@NamedQueries(value = { @NamedQuery(name = "selectAllAudit", query = "SELECT aud FROM AuditData aud WHERE aud.sourceSystem = :sourceSystem") })
public class AuditData {

	private Integer auditId;
	
	private String tenantId;

	private String operationName;

	private String sourceSystem;

	private String targetSystem;
	
	private String reqPayload;
	
	private String respPayload;

	private String createdBy;

	private Date createdDate;

	@Id
	@SequenceGenerator(name = "auditIdSeq", allocationSize = 1, initialValue = 1)
	@Column(name = "AUDIT_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getAuditId() {
		return auditId;
	}

	public void setAuditId(Integer auditId) {
		this.auditId = auditId;
	}

	@Column(name = "OPERATION_NAME", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	@Column(name = "SOURCE_SYSTEM", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Column(name = "TARGET_SYSTEM", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getTargetSystem() {
		return targetSystem;
	}

	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "REQ_PAYLOAD", unique = false, nullable = false, insertable = true, updatable = false)
	public String getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}

	@Column(name = "RES_PAYLOAD", unique = false, nullable = false, insertable = true, updatable = false)
	public String getRespPayload() {
		return respPayload;
	}

	public void setRespPayload(String respPayload) {
		this.respPayload = respPayload;
	}

	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
