package com.poc.auditor.audit.manager.component.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.poc.auditor.audit.manager.component.AuditManagerComponent;
import com.poc.auditor.audit.manager.dao.AuditManagerDAO;
import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditResponseVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.exception.AuditManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Component class for managing Audit Data operations.
 */
@Component
public class AuditManagerComponentImpl implements AuditManagerComponent {

	@Autowired
	private AuditManagerDAO auditManagerDAO;
	
	public AuditManagerDAO getAuditManagerDAO() {
		return auditManagerDAO;
	}

	public void setAuditManagerDAO(AuditManagerDAO auditManagerDAO) {
		this.auditManagerDAO = auditManagerDAO;
	}

	public Boolean saveAuditEntry(AuditRequestVO requestVO) throws AuditManagerException {
		Boolean status = auditManagerDAO.saveAuditEntry(requestVO);
		return status;
	}

	public AuditResponseVO searchAuditEntry(AuditSearchVO searchVO) throws AuditManagerException {
		AuditResponseVO auditResponseVO = new AuditResponseVO();
		if (searchVO != null && searchVO.getFromDate() != null
				&& searchVO.getAuditServiceVOs() != null
				&& !searchVO.getAuditServiceVOs().isEmpty()) {
			auditResponseVO = auditManagerDAO.searchAuditEntry(searchVO);
			auditResponseVO.setStatus(true);
		} else {
			auditResponseVO.setStatus(false);
		}
		return auditResponseVO;
	}

}
