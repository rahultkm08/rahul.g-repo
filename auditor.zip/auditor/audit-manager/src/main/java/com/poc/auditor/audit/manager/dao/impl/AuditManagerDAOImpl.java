package com.poc.auditor.audit.manager.dao.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.poc.auditor.audit.manager.dao.AuditManagerDAO;
import com.poc.auditor.audit.manager.dao.entity.AuditData;
import com.poc.auditor.audit.manager.dto.AuditRequestVO;
import com.poc.auditor.audit.manager.dto.AuditResponseVO;
import com.poc.auditor.audit.manager.dto.AuditSearchVO;
import com.poc.auditor.audit.manager.dto.AuditServiceVO;
import com.poc.auditor.audit.manager.dto.AuditTransactionVO;
import com.poc.auditor.audit.manager.exception.AuditManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * DAO Class for managing Audit Data operations.
 */
@Repository
public class AuditManagerDAOImpl implements AuditManagerDAO {

	/**
	 * logger.
	 */
	final static Logger logger = Logger.getLogger(AuditManagerDAOImpl.class);
	
	protected EntityManager entityManager;
	
	private static String GET_AUDIT_DATA = "SELECT COUNT(aud) FROM AuditData aud WHERE aud.sourceSystem =:sourceSystem AND aud.operationName =:operationName"
			+ " AND aud.createdDate BETWEEN :startDate AND :endDate";
	
	@Autowired
	private Mapper dozerMapper;
	 
    public EntityManager getEntityManager() {
        return entityManager;
    }
    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
	public Boolean saveAuditEntry(AuditRequestVO requestVO) throws AuditManagerException {
    	Boolean status;
    	try {
    		AuditData auditEntity = dozerMapper.map(requestVO, AuditData.class);
    		auditEntity.setCreatedBy(System.getProperty("user.name"));
    		auditEntity.setCreatedDate(new Date());
        	getEntityManager().persist(auditEntity);
        	status = true;
		} catch (Exception e) {
			status = false;
			logger.error("Unable to save Audit : " + requestVO.getTenantId() + " : " + requestVO.getSourceSystem() + " : " + requestVO.getTargetSystem());
			throw new AuditManagerException("Unable to save Audit now, please try again", e);
		}
    	return status;
	}
    
	@Transactional
	public AuditResponseVO searchAuditEntry(AuditSearchVO searchVO) throws AuditManagerException {
		AuditResponseVO auditResponseVO = new AuditResponseVO();
		try {
			auditResponseVO.setAuditServiceVOs(searchVO.getAuditServiceVOs());
			Long recordCount = (long) 0;
			Query q1 = getEntityManager().createQuery(GET_AUDIT_DATA);
			q1.setParameter("startDate", searchVO.getFromDate(), TemporalType.TIMESTAMP);
			q1.setParameter("endDate", searchVO.getToDate(), TemporalType.TIMESTAMP);
			for (AuditServiceVO auditServiceVO : auditResponseVO.getAuditServiceVOs()) {
				q1.setParameter("sourceSystem", auditServiceVO.getServiceName());
				for (AuditTransactionVO auditTransactionVO : auditServiceVO.getTransactionVOs()) {
					q1.setParameter("operationName", auditTransactionVO.getTransactionName());
					recordCount = (Long) q1.getSingleResult();
					System.out.println(recordCount);
					if (recordCount > 0) {
						auditTransactionVO.setAuditStatus(true);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Unable to search Audit");
			throw new AuditManagerException("Unable to search Audit", e);
		}
		return auditResponseVO;
	}

}
