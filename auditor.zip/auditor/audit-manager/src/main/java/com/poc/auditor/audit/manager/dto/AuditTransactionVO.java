package com.poc.auditor.audit.manager.dto;

public class AuditTransactionVO {

	private String transactionName;
	
	private Boolean auditStatus = false;

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public Boolean isAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(Boolean auditStatus) {
		this.auditStatus = auditStatus;
	}
	
}
