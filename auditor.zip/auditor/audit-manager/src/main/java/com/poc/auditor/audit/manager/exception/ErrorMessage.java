package com.poc.auditor.audit.manager.exception;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Class to store the error message on Exception in Audit-Service API.
 */
public class ErrorMessage {
	
	private String error;

	public ErrorMessage(String error) {
		this.error = error;
	}

	public String getError() {
		return error;
	}
}
