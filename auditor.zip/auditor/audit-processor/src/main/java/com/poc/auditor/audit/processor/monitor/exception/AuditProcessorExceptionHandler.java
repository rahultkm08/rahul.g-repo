package com.poc.auditor.audit.processor.monitor.exception;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Handler class for managing Exception on Audit-Processor API.
 */
@Provider
public final class AuditProcessorExceptionHandler implements ExceptionMapper<AuditProcessorException> {

	public Response toResponse(final AuditProcessorException exception) {
		return Response.status(Status.SERVICE_UNAVAILABLE).entity(new ErrorMessage(exception.getMessage()))
				.type(MediaType.APPLICATION_XML).build();
	}

}
