package com.poc.auditor.audit.processor.monitor.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.poc.auditor.audit.processor.monitor.dao.AuditProcessorMonitorDAO;
import com.poc.auditor.audit.processor.monitor.dao.entity.MasterAuditHolidayConfg;
import com.poc.auditor.audit.processor.monitor.dao.entity.MasterAuditMonitorAlertConfg;
import com.poc.auditor.audit.processor.monitor.dao.entity.MasterAuditMonitorWorkingConfg;
import com.poc.auditor.audit.processor.monitor.dao.entity.MasterAuditServiceConfg;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditMonitorAlertConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditMonitorWorkingConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditServiceConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * DAO Class for exposing Monitoring Configuration.
 */
@Repository
public class AuditProcessorMonitorDAOImpl implements AuditProcessorMonitorDAO {

	/**
	 * logger.
	 */
	final static Logger logger = Logger.getLogger(AuditProcessorMonitorDAOImpl.class);
	
	protected EntityManager entityManager;

	private static String SELECT_SERVICE_CONFG = "SELECT serviceConfg from MasterAuditServiceConfg serviceConfg WHERE serviceConfg.isMonitored = 1";

	@Autowired
	private Mapper dozerMapper;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	public MonitorConfigResponseVO getMonitorConfig(MonitorConfigRequestVO requestVO) throws AuditProcessorException {
		MonitorConfigResponseVO configResponseVO = null;
		try {
			StringBuilder sb = new StringBuilder(SELECT_SERVICE_CONFG);
			if (requestVO != null && requestVO.getSourceSystem() != null && !requestVO.getSourceSystem().isEmpty()) {
				sb.append(" AND serviceConfg.serviceName = '").append(requestVO.getSourceSystem()).append("'");
			}
			Query q = getEntityManager().createQuery(sb.toString());
			List<MasterAuditServiceConfg> services = q.getResultList();

			q = getEntityManager().createNamedQuery("selectAllHoliday");
			List<MasterAuditHolidayConfg> holidays = q.getResultList();

			q = getEntityManager().createNamedQuery("selectWorkingConfg");
			MasterAuditMonitorWorkingConfg workingTime = (MasterAuditMonitorWorkingConfg) q.getSingleResult();

			q = getEntityManager().createNamedQuery("selectAllMonitorAlertConfg");
			List<MasterAuditMonitorAlertConfg> alertConfg = q.getResultList();

			configResponseVO = generateResponseVO(services, holidays, workingTime, alertConfg);

		} catch (Exception e) {
			logger.error("Unable to get Monitoring Configuration : " + requestVO.getTenantId() + " : "
					+ requestVO.getSourceSystem());
			throw new AuditProcessorException("Unable to get Monitoring Configuration", e);
		}
		return configResponseVO;
	}

	private MonitorConfigResponseVO generateResponseVO(List<MasterAuditServiceConfg> services,
			List<MasterAuditHolidayConfg> holidays, MasterAuditMonitorWorkingConfg workingTime,
			List<MasterAuditMonitorAlertConfg> alertConfg) {
		MonitorConfigResponseVO configResponseVO = null;
		if (services != null && alertConfg != null && workingTime != null) {
			configResponseVO = new MonitorConfigResponseVO();
			List<MasterAuditServiceConfgVO> auditServiceConfgVOs = new ArrayList<MasterAuditServiceConfgVO>();
			for (MasterAuditServiceConfg service : services) {
				auditServiceConfgVOs.add(dozerMapper.map(service, MasterAuditServiceConfgVO.class));
			}
			configResponseVO.setMonitorServices(auditServiceConfgVOs);

			List<MasterAuditMonitorAlertConfgVO> alertConfgVOs = new ArrayList<MasterAuditMonitorAlertConfgVO>();
			for (MasterAuditMonitorAlertConfg alert : alertConfg) {
				alertConfgVOs.add(dozerMapper.map(alert, MasterAuditMonitorAlertConfgVO.class));
			}
			configResponseVO.setMonitorAlertConfgs(alertConfgVOs);

			configResponseVO
					.setMonitorWorkingConfg(dozerMapper.map(workingTime, MasterAuditMonitorWorkingConfgVO.class));

			if (holidays != null && !holidays.isEmpty()) {
				configResponseVO.setHolidays(new ArrayList<Date>());
				for (MasterAuditHolidayConfg holiday : holidays) {
					if (holiday != null) {
						configResponseVO.getHolidays().add(holiday.getHolidayDate());
					}
				}
			}
			configResponseVO.setStatus(true);
		}
		return configResponseVO;
	}

}
