package com.poc.auditor.audit.processor.monitor.dto;

public class MasterAuditMonitorWorkingConfgVO {

	private Integer startHour;

	private Integer startMinute;

	private Integer endHour;

	private Integer endMinute;

	private Integer startAlertBuffer;
	
	private Integer endAlertBuffer;
	
	private String businessDays;

	public Integer getStartHour() {
		return startHour;
	}

	public void setStartHour(Integer startHour) {
		this.startHour = startHour;
	}

	public Integer getStartMinute() {
		return startMinute;
	}

	public void setStartMinute(Integer startMinute) {
		this.startMinute = startMinute;
	}

	public Integer getEndHour() {
		return endHour;
	}

	public void setEndHour(Integer endHour) {
		this.endHour = endHour;
	}

	public Integer getEndMinute() {
		return endMinute;
	}

	public void setEndMinute(Integer endMinute) {
		this.endMinute = endMinute;
	}

	public Integer getStartAlertBuffer() {
		return startAlertBuffer;
	}

	public void setStartAlertBuffer(Integer startAlertBuffer) {
		this.startAlertBuffer = startAlertBuffer;
	}

	public Integer getEndAlertBuffer() {
		return endAlertBuffer;
	}

	public void setEndAlertBuffer(Integer endAlertBuffer) {
		this.endAlertBuffer = endAlertBuffer;
	}
	
	public String getBusinessDays() {
		return businessDays;
	}

	public void setBusinessDays(String businessDays) {
		this.businessDays = businessDays;
	}
	
}
