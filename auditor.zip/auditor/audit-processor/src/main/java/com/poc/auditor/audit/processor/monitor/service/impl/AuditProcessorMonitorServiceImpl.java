package com.poc.auditor.audit.processor.monitor.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.poc.auditor.audit.processor.monitor.component.AuditProcessorMonitorComponent;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;
import com.poc.auditor.audit.processor.monitor.service.AuditProcessorMonitorService;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for exposing Monitoring Configuration.
 */
public class AuditProcessorMonitorServiceImpl implements
		AuditProcessorMonitorService {

	@Autowired
	private AuditProcessorMonitorComponent auditProcessorComponent;

	public AuditProcessorMonitorComponent getAuditProcessorComponent() {
		return auditProcessorComponent;
	}

	public void setAuditProcessorComponent(
			AuditProcessorMonitorComponent auditProcessorComponent) {
		this.auditProcessorComponent = auditProcessorComponent;
	}

	public MonitorConfigResponseVO getMonitorConfig(MonitorConfigRequestVO requestVO) throws AuditProcessorException {
		MonitorConfigResponseVO configResponseVO = auditProcessorComponent.getMonitorConfig(requestVO);
		return configResponseVO;
	}

}
