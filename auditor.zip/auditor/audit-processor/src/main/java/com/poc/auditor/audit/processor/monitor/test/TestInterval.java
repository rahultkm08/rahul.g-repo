package com.poc.auditor.audit.processor.monitor.test;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class TestInterval {

	static Map<String, Integer> repeatInterval = new HashMap<String, Integer>();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		repeatInterval.put("DEFAULT", 10);
		repeatInterval.put("10-13", 30);
		System.out.println(getInterval(repeatInterval));

	}

	private static int getInterval(Map<String, Integer> repeatInterval2) {
		String defaultPattern = "DEFAULT";
		Integer defaultInterval = 0;
		Calendar current = Calendar.getInstance();
		int currentTime = current.get(Calendar.HOUR_OF_DAY);
		try {
			for (Entry<String, Integer> entry : repeatInterval.entrySet()) {
				/*if (!entry.getKey().equalsIgnoreCase(defaultPattern)) {
					String[] rangeBoundary = entry.getKey().split("-");
					String fromTime = rangeBoundary[0];
					String toTime = rangeBoundary[1];
					if (currentTime >= Integer.parseInt(fromTime)
							&& currentTime < Integer.parseInt(toTime)) {
						defaultInterval = entry.getValue();
						break;
					}
				} else if (entry.getKey().equalsIgnoreCase(defaultPattern)) {
					defaultInterval = repeatInterval.get(defaultPattern);
				}*/
				if (entry.getKey() != "DEFAULT") {
					String[] rangeBoundary = entry.getKey().split("-");
					String fromTime = rangeBoundary[0];
					String toTime = rangeBoundary[1];
					if (currentTime >= Integer.parseInt(fromTime) && currentTime < Integer.parseInt(toTime)) {
						return entry.getValue();
					}
				}
				return repeatInterval.get("DEFAULT");
			}
		} catch (Exception e) {
			e.printStackTrace();
			defaultInterval = 10;
		}
		System.out.println("Setting default interval");
		return defaultInterval;
	}
}
