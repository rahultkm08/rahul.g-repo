package com.poc.auditor.audit.processor.monitor.dao;

import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;

public interface AuditProcessorMonitorDAO {

	public MonitorConfigResponseVO getMonitorConfig(MonitorConfigRequestVO requestVO) throws AuditProcessorException;

}
