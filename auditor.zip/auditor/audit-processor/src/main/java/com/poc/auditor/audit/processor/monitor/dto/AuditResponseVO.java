package com.poc.auditor.audit.processor.monitor.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuditResponseVO")
@XmlRootElement(name = "AuditResponseVO")
public class AuditResponseVO {

	@XmlElement(name = "Status", required = true)
	private Boolean status;

	private List<AuditServiceVO> auditServiceVOs;
	
	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public List<AuditServiceVO> getAuditServiceVOs() {
		return auditServiceVOs;
	}

	public void setAuditServiceVOs(List<AuditServiceVO> auditServiceVOs) {
		this.auditServiceVOs = auditServiceVOs;
	}
	
}
