package com.poc.auditor.audit.processor.monitor.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for exposing Monitoring Configuration.
 */
@Component
@Path("/process-monitor")
public interface AuditProcessorMonitorService {

	@POST
	@Path("/getMonitorConfig")
	@Consumes({ MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_XML })
	public MonitorConfigResponseVO getMonitorConfig(MonitorConfigRequestVO requestVO) throws AuditProcessorException;

}
