package com.poc.auditor.audit.processor.monitor.dto;

public class MasterAuditTransactionConfgVO {

	private String transactionName;

	private Integer isMonitored;
	
	private String monitorPattern;
	
	private boolean auditStatus;

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public Integer getIsMonitored() {
		return isMonitored;
	}

	public void setIsMonitored(Integer isMonitored) {
		this.isMonitored = isMonitored;
	}

	public String getMonitorPattern() {
		return monitorPattern;
	}

	public void setMonitorPattern(String monitorPattern) {
		this.monitorPattern = monitorPattern;
	}

	public boolean isAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(boolean auditStatus) {
		this.auditStatus = auditStatus;
	}
	
}
