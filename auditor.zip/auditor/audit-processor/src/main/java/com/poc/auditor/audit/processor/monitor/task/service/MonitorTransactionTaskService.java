package com.poc.auditor.audit.processor.monitor.task.service;

import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;

public interface MonitorTransactionTaskService {

	public MonitorConfigResponseVO getJobConfg(MonitorConfigRequestVO requestVO) throws AuditProcessorException;
	
	public Boolean doValidation(MonitorConfigResponseVO requestVO);
	
	public Boolean startMonitorProcessing();
	
}
