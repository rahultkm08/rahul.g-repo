package com.poc.auditor.audit.processor.monitor.test;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class TestFileAppend {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			FileWriter writer = new FileWriter("AuditLog.txt", true);
			writer.write(new Date().toString());

			for (int i = 0; i < 2; i++) {
				writer.write(" PIP New");
				writer.write(":: ");
				writer.write("ITEM_IMPORT");
				writer.write(":: ");
				writer.write("true");
				writer.write("\r\n"); // write new line
			}

			writer.close();
		} catch (IOException e) {
			System.out.println("Exception while writing into file : "
					+ e.getMessage());
		}
	}

}
