package com.poc.auditor.audit.processor.monitor.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Monitoring exempted Holidays.
 */
@Entity
@Table(name = "AUDT_MSTR_HOLIDAY_CONFG")
@NamedQueries(value = { @NamedQuery(name = "selectAllHoliday", query = "SELECT holiday FROM MasterAuditHolidayConfg holiday") })
public class MasterAuditHolidayConfg {

	private Integer holidayId;
	
	private String tenantId;
	
	private Date holidayDate;

	private String createdBy;

	private Date createdDate;
	
	@Id
	@Column(name = "HOLIDAY_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@SequenceGenerator(name = "holidayIdSeq", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getHolidayId() {
		return holidayId;
	}

	public void setHolidayId(Integer holidayId) {
		this.holidayId = holidayId;
	}

	@Column(name = "HOLIDAY_DATE", unique = true, nullable = false, insertable = true, updatable = true)
	public Date getHolidayDate() {
		return holidayDate;
	}

	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
}
