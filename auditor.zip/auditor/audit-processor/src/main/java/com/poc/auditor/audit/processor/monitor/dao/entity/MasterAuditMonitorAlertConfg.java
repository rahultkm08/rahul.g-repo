package com.poc.auditor.audit.processor.monitor.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Monitoring alert pattern configuration.
 */
@Entity
@Table(name = "AUDT_MSTR_ALERT_CONFG")
@NamedQueries(value = { @NamedQuery(name = "selectAllMonitorAlertConfg", query = "SELECT alertConfg FROM MasterAuditMonitorAlertConfg alertConfg") })
public class MasterAuditMonitorAlertConfg {

	private Integer alertConfgId;
	
	private String tenantId;
	
	private String alertConfgName;

	private String alertConfgValue;

	private Integer intervalOriginal;

	private Integer intervalDay;
	
	private String createdBy;

	private Date createdDate;
	
	private String lastModifiedBy;

	private Date lastModifiedDate;

	@Id
	@Column(name = "ALERT_CONFG_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@SequenceGenerator(name = "alertConfgIdSeq", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getAlertConfgId() {
		return alertConfgId;
	}

	public void setAlertConfgId(Integer alertConfgId) {
		this.alertConfgId = alertConfgId;
	}

	@Column(name = "ALERT_CONFG_NAME", unique = true, nullable = false, insertable = true, updatable = true)
	public String getAlertConfgName() {
		return alertConfgName;
	}

	public void setAlertConfgName(String alertConfgName) {
		this.alertConfgName = alertConfgName;
	}

	@Column(name = "ALERT_CONFG_VALUE", unique = true, nullable = false, insertable = true, updatable = true)
	public String getAlertConfgValue() {
		return alertConfgValue;
	}

	public void setAlertConfgValue(String alertConfgValue) {
		this.alertConfgValue = alertConfgValue;
	}

	@Column(name = "INTERVAL_ORIGINAL", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public Integer getIntervalOriginal() {
		return intervalOriginal;
	}

	public void setIntervalOriginal(Integer intervalOriginal) {
		this.intervalOriginal = intervalOriginal;
	}

	@Column(name = "INTERVAL_DAY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public Integer getIntervalDay() {
		return intervalDay;
	}

	public void setIntervalDay(Integer intervalDay) {
		this.intervalDay = intervalDay;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "LAST_MODIFIED_BY", unique = true, nullable = false, insertable = true, updatable = true)
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	@Column(name = "LAST_MODIFIED_DATE", unique = true, nullable = false, insertable = true, updatable = true)
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
}
