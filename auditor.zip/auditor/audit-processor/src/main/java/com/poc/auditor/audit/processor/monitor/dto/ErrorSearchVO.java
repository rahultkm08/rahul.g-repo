package com.poc.auditor.audit.processor.monitor.dto;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ErrorSearchVO")
@XmlRootElement(name = "ErrorSearchVO")

public class ErrorSearchVO {

	@XmlElement(name = "AuditServiceVOs", required = true)
	private List<AuditServiceVO> auditServiceVOs;
	
	@XmlElement(name = "FromDate", required = true)
	private Date fromDate;
	
	@XmlElement(name = "ToDate", required = true)
	private Date toDate;

	public List<AuditServiceVO> getAuditServiceVOs() {
		return auditServiceVOs;
	}

	public void setAuditServiceVOs(List<AuditServiceVO> auditServiceVOs) {
		this.auditServiceVOs = auditServiceVOs;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
}
