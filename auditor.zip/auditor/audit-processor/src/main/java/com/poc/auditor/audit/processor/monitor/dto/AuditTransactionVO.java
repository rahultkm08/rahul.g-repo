package com.poc.auditor.audit.processor.monitor.dto;

public class AuditTransactionVO {

	private String transactionName;
	
	private boolean auditStatus;

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public boolean isAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(boolean auditStatus) {
		this.auditStatus = auditStatus;
	}
	
}
