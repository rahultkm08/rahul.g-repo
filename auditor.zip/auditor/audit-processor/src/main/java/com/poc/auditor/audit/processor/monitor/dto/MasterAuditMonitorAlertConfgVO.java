package com.poc.auditor.audit.processor.monitor.dto;


public class MasterAuditMonitorAlertConfgVO {

	private String alertConfgName;

	private String alertConfgValue;

	private Integer intervalOriginal;

	private Integer intervalDay;

	public String getAlertConfgName() {
		return alertConfgName;
	}

	public void setAlertConfgName(String alertConfgName) {
		this.alertConfgName = alertConfgName;
	}

	public String getAlertConfgValue() {
		return alertConfgValue;
	}

	public void setAlertConfgValue(String alertConfgValue) {
		this.alertConfgValue = alertConfgValue;
	}

	public Integer getIntervalOriginal() {
		return intervalOriginal;
	}

	public void setIntervalOriginal(Integer intervalOriginal) {
		this.intervalOriginal = intervalOriginal;
	}

	public Integer getIntervalDay() {
		return intervalDay;
	}

	public void setIntervalDay(Integer intervalDay) {
		this.intervalDay = intervalDay;
	}
	
}
