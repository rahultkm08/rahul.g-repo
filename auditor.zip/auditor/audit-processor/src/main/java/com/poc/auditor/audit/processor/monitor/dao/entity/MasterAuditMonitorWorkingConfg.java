package com.poc.auditor.audit.processor.monitor.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Monitoring work configuration.
 */
@Entity
@Table(name = "AUDT_MSTR_WORKING_CONFG")
@NamedQueries(value = { @NamedQuery(name = "selectWorkingConfg", query = "SELECT monitorWorking FROM MasterAuditMonitorWorkingConfg monitorWorking") })
public class MasterAuditMonitorWorkingConfg {

	private Integer workId;
	
	private String tenantId;
	
	private Integer startHour;
	
	private Integer startMinute;

	private Integer endHour;
	
	private Integer endMinute;
	
	private Integer startAlertBuffer;
	
	private Integer endAlertBuffer;
	
	private String businessDays;
	
	private String createdBy;

	private Date createdDate;
	
	@Id
	@Column(name = "WORK_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@SequenceGenerator(name = "workIdSeq", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getWorkId() {
		return workId;
	}

	public void setWorkId(Integer workId) {
		this.workId = workId;
	}

	@Column(name = "START_HOUR", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getStartHour() {
		return startHour;
	}

	public void setStartHour(Integer startHour) {
		this.startHour = startHour;
	}

	@Column(name = "START_MINUTE", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getStartMinute() {
		return startMinute;
	}

	public void setStartMinute(Integer startMinute) {
		this.startMinute = startMinute;
	}

	@Column(name = "END_HOUR", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getEndHour() {
		return endHour;
	}

	public void setEndHour(Integer endHour) {
		this.endHour = endHour;
	}

	@Column(name = "END_MINUTE", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getEndMinute() {
		return endMinute;
	}

	public void setEndMinute(Integer endMinute) {
		this.endMinute = endMinute;
	}

	@Column(name = "START_ALERT_BUFFER", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getStartAlertBuffer() {
		return startAlertBuffer;
	}

	public void setStartAlertBuffer(Integer startAlertBuffer) {
		this.startAlertBuffer = startAlertBuffer;
	}

	@Column(name = "END_ALERT_BUFFER", unique = false, nullable = false, insertable = true, updatable = false)
	public Integer getEndAlertBuffer() {
		return endAlertBuffer;
	}

	public void setEndAlertBuffer(Integer endAlertBuffer) {
		this.endAlertBuffer = endAlertBuffer;
	}

	@Column(name = "BUSINESS_DAYS", unique = true, nullable = false, insertable = true, updatable = true)
	public String getBusinessDays() {
		return businessDays;
	}

	public void setBusinessDays(String businessDays) {
		this.businessDays = businessDays;
	}
	
	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
