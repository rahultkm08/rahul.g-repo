package com.poc.auditor.audit.processor.monitor.dao.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Monitoring required Services configuration.
 */
@Entity
@Table(name = "AUDT_MSTR_SERVICE_CONFG")
public class MasterAuditServiceConfg {

	private Integer serviceId;
	
	private String tenantId;

	private String serviceName;

	private String alertToMailAddress;

	private Integer isMonitored;
	
	private String createdBy;

	private Date createdDate;
	
	private List<MasterAuditTransactionConfg> transactionNames;
	
	@Id
	@Column(name = "SERVICE_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@SequenceGenerator(name = "serviceIdSeq", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	@Column(name = "SERVICE_NAME", unique = false, nullable = false, insertable = true, updatable = true)
	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	@Column(name = "ALERT_TO_MAIL_ADDRESS", unique = false, nullable = false, insertable = true, updatable = true)
	public String getAlertToMailAddress() {
		return alertToMailAddress;
	}

	public void setAlertToMailAddress(String alertToMailAddress) {
		this.alertToMailAddress = alertToMailAddress;
	}

	@Column(name = "IS_MONITORED", unique = false, nullable = false, insertable = true, updatable = true)
	public Integer getIsMonitored() {
		return isMonitored;
	}

	public void setIsMonitored(Integer isMonitored) {
		this.isMonitored = isMonitored;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinColumn(name="SERVICE_ID")
	public List<MasterAuditTransactionConfg> getTransactionNames() {
		return transactionNames;
	}

	public void setTransactionNames(
			List<MasterAuditTransactionConfg> transactionNames) {
		this.transactionNames = transactionNames;
	}
	
	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
