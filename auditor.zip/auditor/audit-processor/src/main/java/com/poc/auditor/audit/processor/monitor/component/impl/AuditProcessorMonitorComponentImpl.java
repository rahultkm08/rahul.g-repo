package com.poc.auditor.audit.processor.monitor.component.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.poc.auditor.audit.processor.monitor.component.AuditProcessorMonitorComponent;
import com.poc.auditor.audit.processor.monitor.dao.AuditProcessorMonitorDAO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Component Class for exposing Monitoring Configuration.
 */
@Component
public class AuditProcessorMonitorComponentImpl implements AuditProcessorMonitorComponent {

	@Autowired
	private AuditProcessorMonitorDAO auditProcessorMonitorDAO;
	
	public AuditProcessorMonitorDAO getAuditProcessorMonitorDAO() {
		return auditProcessorMonitorDAO;
	}

	public void setAuditProcessorMonitorDAO(
			AuditProcessorMonitorDAO auditProcessorMonitorDAO) {
		this.auditProcessorMonitorDAO = auditProcessorMonitorDAO;
	}

	public MonitorConfigResponseVO getMonitorConfig(
			MonitorConfigRequestVO requestVO) throws AuditProcessorException {
		return auditProcessorMonitorDAO.getMonitorConfig(requestVO);
	}

}
