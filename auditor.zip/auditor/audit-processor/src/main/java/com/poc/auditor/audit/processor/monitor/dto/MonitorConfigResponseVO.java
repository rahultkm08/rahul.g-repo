package com.poc.auditor.audit.processor.monitor.dto;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MonitorConfigResponseVO")
@XmlRootElement(name = "MonitorConfigResponseVO")
public class MonitorConfigResponseVO {

	@XmlElement(name = "Status", required = true, defaultValue = "false")
	private Boolean status;

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	List<MasterAuditServiceConfgVO> monitorServices;

	private List<Date> holidays;
	
	private MasterAuditMonitorWorkingConfgVO monitorWorkingConfg;
	
	private List<MasterAuditMonitorAlertConfgVO> monitorAlertConfgs;

	public List<MasterAuditServiceConfgVO> getMonitorServices() {
		return monitorServices;
	}

	public void setMonitorServices(List<MasterAuditServiceConfgVO> monitorServices) {
		this.monitorServices = monitorServices;
	}

	public List<MasterAuditMonitorAlertConfgVO> getMonitorAlertConfgs() {
		return monitorAlertConfgs;
	}

	public void setMonitorAlertConfgs(
			List<MasterAuditMonitorAlertConfgVO> monitorAlertConfgs) {
		this.monitorAlertConfgs = monitorAlertConfgs;
	}

	public List<Date> getHolidays() {
		return holidays;
	}

	public void setHolidays(List<Date> holidays) {
		this.holidays = holidays;
	}

	public MasterAuditMonitorWorkingConfgVO getMonitorWorkingConfg() {
		return monitorWorkingConfg;
	}

	public void setMonitorWorkingConfg(MasterAuditMonitorWorkingConfgVO monitorWorkingConfg) {
		this.monitorWorkingConfg = monitorWorkingConfg;
	}

}
