package com.poc.auditor.audit.processor.monitor.test;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.cxf.jaxrs.client.WebClient;

import com.poc.auditor.audit.processor.monitor.dto.ErrorResponseVO;
import com.poc.auditor.audit.processor.monitor.dto.ErrorSearchVO;

public class TestWSCall {

	public static final String SERVICE_HOST = "http://localhost:8080";

	public static void main(String[] args) {
		try {
			ErrorSearchVO searchVO = null;
			InputStream inputStream = new FileInputStream("error-search-req.xml");
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			// InputSource is = new InputSource(reader);
			JAXBContext context;
			context = JAXBContext.newInstance(ErrorSearchVO.class);
			Unmarshaller um = context.createUnmarshaller();
			searchVO = (ErrorSearchVO) um.unmarshal(reader);
			WebClient client = WebClient.create(SERVICE_HOST);
			client.path("error-manager/services/error-data/searchError");
			client.type("application/xml").accept("application/xml");
			ErrorResponseVO responseVO = client.post(searchVO, ErrorResponseVO.class);
			//Response res = client.post(searchVO);
			//ErrorResponseVO responseVO1 = (ErrorResponseVO) res.getEntity();
			/*System.out
					.println("Response Status for Search: " + res.getStatus());*/
			System.out.println("done->  " + responseVO.getStatus());
			// return responseVO;
		} catch (Exception e) {
			System.out.println("Exception while executing search service: "
					+ e.getMessage());
		}
	}

}
