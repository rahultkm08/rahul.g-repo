package com.poc.auditor.audit.processor.monitor.exception;

import java.io.Serializable;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Exception class for managing Audit-Processor API errors.
 */
public class AuditProcessorException extends Exception implements Serializable {

	private static final long serialVersionUID = -4873736688422645862L;

	public AuditProcessorException() {
		super();
	}

	public AuditProcessorException(String msg) {
		super(msg);
	}

	public AuditProcessorException(String msg, Exception e) {
		super(msg, e);
	}
}
