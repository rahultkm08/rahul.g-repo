package com.poc.auditor.audit.processor.monitor.task.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.poc.auditor.audit.processor.monitor.component.AuditProcessorMonitorComponent;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditMonitorAlertConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigResponseVO;
import com.poc.auditor.audit.processor.monitor.exception.AuditProcessorException;
import com.poc.auditor.audit.processor.monitor.task.executor.MonitorTransactionTaskExecutor;
import com.poc.auditor.audit.processor.monitor.task.service.MonitorTransactionTaskService;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entry point of Job to handle the Monitoring & Alerting based on the Configuration.
 */
public class MonitorTransactionTaskServiceImpl implements MonitorTransactionTaskService {

	/**
	 * logger.
	 */
	final static Logger logger = Logger.getLogger(MonitorTransactionTaskServiceImpl.class);
	
	@Autowired
	private AuditProcessorMonitorComponent auditProcessorComponent;

	
	public MonitorConfigResponseVO getJobConfg(MonitorConfigRequestVO requestVO) throws AuditProcessorException {
		MonitorConfigResponseVO configResponseVO = auditProcessorComponent.getMonitorConfig(requestVO);
		return configResponseVO;
	}

	public Boolean doValidation(MonitorConfigResponseVO requestVO) {
		Boolean status = true;
		if (requestVO != null) {
			if (requestVO.getHolidays() != null && !requestVO.getHolidays().isEmpty()) {
				Calendar c = Calendar.getInstance();
				int year_today = c.get(Calendar.YEAR);
				int month_today = c.get(Calendar.MONTH);
				int day_today = c.get(Calendar.DAY_OF_MONTH);

				int year_fromDB, month_fromDB, day_fromDB;
				Calendar c1 = Calendar.getInstance();
				for (Date fromDB : requestVO.getHolidays()) {
					c1.setTime(fromDB);
					year_fromDB = c1.get(Calendar.YEAR);
					month_fromDB = c1.get(Calendar.MONTH);
					day_fromDB = c1.get(Calendar.DAY_OF_MONTH);
					if (year_today == year_fromDB && month_today == month_fromDB && day_today == day_fromDB) {
						status = false;
						break;
					}
				}

				/*
				 * if (requestVO.getStoreHolidays().contains(new Date())) {
				 * status = false; }
				 */
			}

			if (status == true && requestVO.getMonitorWorkingConfg() != null) {
				if (!requestVO.getMonitorWorkingConfg().getBusinessDays()
						.contains(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_WEEK)))) {
					status = false;
				}
			}
		} else {
			status = false;
		}
		return status;
	}

	public Boolean startMonitorProcessing() {
		return null;
	}
	
	//"0 15 7 ? * *" //everyday 7.15
	//(cron = "0 57 14 ? * *")
	@Scheduled(fixedRate = 10000, initialDelay = 5000)	//starts after 5 mint/run often 10 mint
	public void TriggerMonitor() {
		MonitorConfigResponseVO monitorConfigResponseVO;
		try {
			monitorConfigResponseVO = getJobConfg(null);
			Boolean valid = doValidation(monitorConfigResponseVO);
			if (valid) {
				Map<String, Integer> intervalMap = getIntervalMap(monitorConfigResponseVO.getMonitorAlertConfgs());
				MonitorTransactionTaskExecutor transactionProcessor = new MonitorTransactionTaskExecutor();
				transactionProcessor.setSchedularParameters(monitorConfigResponseVO.getMonitorServices(),
						monitorConfigResponseVO.getMonitorWorkingConfg(), intervalMap);
				transactionProcessor.startSchedular();
			} else {
				logger.error("No Valid Configuration to run Monitoring system");
			}
		} catch (AuditProcessorException e) {
			logger.error("Unable to run Monitoring system");
		}
	}

	private Map<String, Integer> getIntervalMap(List<MasterAuditMonitorAlertConfgVO> monitorAlertConfgs) {
		Map<String, Integer> intervalMap = new HashMap<String, Integer>();

		for (MasterAuditMonitorAlertConfgVO alertCong : monitorAlertConfgs) {
			intervalMap.put(alertCong.getAlertConfgValue(), alertCong.getIntervalDay());
		}

		return intervalMap;
	}

}
