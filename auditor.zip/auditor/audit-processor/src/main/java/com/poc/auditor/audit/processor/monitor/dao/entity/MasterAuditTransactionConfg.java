package com.poc.auditor.audit.processor.monitor.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Monitoring required Transactions configuration related to each Service.
 */
@Entity
@Table(name = "AUDT_MSTR_TRANSACTION_CONFG")
public class MasterAuditTransactionConfg {

	private Integer transactionId;
	
	private String transactionName;

	private Integer isMonitored;
	
	private String monitorPattern;
	
	private String createdBy;

	private Date createdDate;
	
	@Id
	@Column(name = "TRANSACTION_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@SequenceGenerator(name = "transactionIdSeq", allocationSize = 1, initialValue = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	@Column(name = "TRANSACTION_NAME", unique = true, nullable = false, insertable = true, updatable = true)
	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	@Column(name = "IS_MONITORED", unique = true, nullable = false, insertable = true, updatable = true)
	public Integer getIsMonitored() {
		return isMonitored;
	}
	
	public void setIsMonitored(Integer isMonitored) {
		this.isMonitored = isMonitored;
	}

	@Column(name = "MONITOR_PATTERN", unique = true, nullable = false, insertable = true, updatable = true)
	public String getMonitorPattern() {
		return monitorPattern;
	}

	public void setMonitorPattern(String monitorPattern) {
		this.monitorPattern = monitorPattern;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
