package com.poc.auditor.audit.processor.monitor.dto;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuditSearchVO")
@XmlRootElement(name = "AuditSearchVO")
public class AuditSearchVO {

	/*@XmlElement(name = "SourceSystem", required = true)
	private String sourceSystem;*/
	
	@XmlElement(name = "AuditServiceVOs", required = true)
	private List<AuditServiceVO> auditServiceVOs;
	
	@XmlElement(name = "FromDate", required = true)
	private Date fromDate;
	
	@XmlElement(name = "ToDate", required = true)
	private Date toDate;

	/*public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}*/

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public List<AuditServiceVO> getAuditServiceVOs() {
		return auditServiceVOs;
	}

	public void setAuditServiceVOs(List<AuditServiceVO> auditServiceVOs) {
		this.auditServiceVOs = auditServiceVOs;
	}
	
}
