package com.poc.auditor.audit.processor.monitor.test;

import java.util.Calendar;
import java.util.Date;

public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
				+ "-> " + new Date());

		Calendar calendar = Calendar.getInstance();
		System.out.println(calendar.getTime());
		/*calendar.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.SECOND, 0);*/
		calendar.set(Calendar.MINUTE, 30);
		calendar.set(Calendar.HOUR, 11);
		System.out.println(calendar.getTime());
		
		Date startBuffer = new Date(calendar.getTimeInMillis() + (-45 * 60000));
		System.out.println("startBuffer -> " + startBuffer);

		/*System.out.println(calendar.get(Calendar.YEAR) + " "
				+ calendar.get(Calendar.MONTH) + " "
				+ calendar.get(Calendar.DAY_OF_MONTH) + " "
				+ calendar.get(Calendar.DATE));
		
		int x = 0;
		print(x);*/

		long l = new Long("1478247918779");
		Calendar cn = Calendar.getInstance();
		cn.setTimeInMillis(l);
		System.out.println("job start-> " + cn.getTime());
	}

	private static void print(int x) {
		System.out.println(x);
		int temp = 0;
		for (int i = 0; i < 2; i++) {
			System.out.println(temp + "hi");
		}
		
	}

}
