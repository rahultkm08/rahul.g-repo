package com.poc.auditor.audit.processor.monitor.dto;

import java.util.List;

public class MasterAuditServiceConfgVO {

	private String serviceName;

	private String alertToMailAddress;

	private Integer isMonitored;
	
	private List<MasterAuditTransactionConfgVO> transactionNames;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getAlertToMailAddress() {
		return alertToMailAddress;
	}

	public void setAlertToMailAddress(String alertToMailAddress) {
		this.alertToMailAddress = alertToMailAddress;
	}

	public Integer getIsMonitored() {
		return isMonitored;
	}

	public void setIsMonitored(Integer isMonitored) {
		this.isMonitored = isMonitored;
	}

	public List<MasterAuditTransactionConfgVO> getTransactionNames() {
		return transactionNames;
	}

	public void setTransactionNames(
			List<MasterAuditTransactionConfgVO> transactionNames) {
		this.transactionNames = transactionNames;
	}
	
}
