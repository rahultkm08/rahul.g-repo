package com.poc.auditor.audit.processor.monitor.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MonitorConfigRequestVO")
@XmlRootElement(name = "MonitorConfigRequestVO")
public class MonitorConfigRequestVO {

	@XmlElement(name = "SourceSystem", required = false)
	private String sourceSystem;
	
	@XmlElement(name = "TenantId", required = false)
	private String tenantId;

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

}
