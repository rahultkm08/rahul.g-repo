package com.poc.auditor.audit.processor.monitor.dto;

import java.util.List;

public class AuditServiceVO {

	private String serviceName;
	
	private List<AuditTransactionVO> transactionVOs;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public List<AuditTransactionVO> getTransactionVOs() {
		return transactionVOs;
	}

	public void setTransactionVOs(List<AuditTransactionVO> transactionVOs) {
		this.transactionVOs = transactionVOs;
	}
	
}
