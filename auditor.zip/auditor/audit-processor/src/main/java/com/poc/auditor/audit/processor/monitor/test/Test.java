package com.poc.auditor.audit.processor.monitor.test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.poc.auditor.audit.processor.monitor.dao.entity.MasterAuditMonitorAlertConfg;
import com.poc.auditor.audit.processor.monitor.dto.MonitorConfigRequestVO;

public class Test {

	public static void main(String[] args) {

		try {
			MonitorConfigRequestVO requestVO = new MonitorConfigRequestVO();
			requestVO.setTenantId("Tenant1");
			requestVO.setSourceSystem("BOOKING");
			JAXBContext context;
			BufferedWriter writer = null;
			writer = new BufferedWriter(new FileWriter("process-monitor-req.xml"));
			context = JAXBContext.newInstance(MonitorConfigRequestVO.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(requestVO, writer);
			writer.close();

			List<MasterAuditMonitorAlertConfg> alertConfgs = new ArrayList<MasterAuditMonitorAlertConfg>();
			MasterAuditMonitorAlertConfg alertConfg = new MasterAuditMonitorAlertConfg();
			alertConfg.setAlertConfgName("A1");

			/*Mapper mapper = new DozerBeanMapper();

			List<MasterAuditMonitorAlertConfgVO> alertConfgVOs = (List<MasterAuditMonitorAlertConfgVO>) mapper
					.map(alertConfgs, MasterAuditMonitorAlertConfgVO.class);*/
			
			System.out.println("Done");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
