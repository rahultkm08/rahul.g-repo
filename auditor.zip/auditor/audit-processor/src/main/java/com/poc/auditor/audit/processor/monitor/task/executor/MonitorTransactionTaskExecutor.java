package com.poc.auditor.audit.processor.monitor.task.executor;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.cxf.jaxrs.client.WebClient;

import com.poc.auditor.audit.processor.monitor.dto.AuditResponseVO;
import com.poc.auditor.audit.processor.monitor.dto.AuditSearchVO;
import com.poc.auditor.audit.processor.monitor.dto.AuditServiceVO;
import com.poc.auditor.audit.processor.monitor.dto.AuditTransactionVO;
import com.poc.auditor.audit.processor.monitor.dto.ErrorResponseVO;
import com.poc.auditor.audit.processor.monitor.dto.ErrorSearchVO;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditMonitorWorkingConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditServiceConfgVO;
import com.poc.auditor.audit.processor.monitor.dto.MasterAuditTransactionConfgVO;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Job to handle the Monitoring & Alerting based on the Configuration.
 */
public class MonitorTransactionTaskExecutor {

	//static StringBuilder alertReport = null;

	Timer timer = new Timer();
	Timer timerRepeat = new Timer();
	Integer currentInterval = 10; // in min

	public static final Integer START_BUFFER = 5; // in min.
	public static final Integer END_BUFFER = 120; // in min.
	public static final Integer ONE_MINUTE_IN_MILLIS = 60000;

	public static final String SERVICE_HOST = "http://localhost:8080";

	Map<String, Integer> repeatInterval = new HashMap<String, Integer>();

	Date startBuffer;
	Date endBuffer;

	List<AuditServiceVO> serviceListForSearch = new ArrayList<AuditServiceVO>();

	List<MasterAuditServiceConfgVO> monitorServices = new ArrayList<MasterAuditServiceConfgVO>();
	int startHour = 0;
	int endHour = 0;
	int startMinute = 0;
	int endMinute = 0;

	private class MyTimeTask extends TimerTask {
		public void run() {

			AuditSearchVO reqSearchVO = new AuditSearchVO();

			Calendar date = Calendar.getInstance();
			long t = date.getTimeInMillis();
			Date fromDate = new Date(t - (currentInterval * ONE_MINUTE_IN_MILLIS));
			reqSearchVO.setFromDate(fromDate);

			reqSearchVO.setAuditServiceVOs(serviceListForSearch);

			// call Audit service
			AuditResponseVO searchResponse = callSearchService(reqSearchVO);

			ErrorSearchVO rqErrorSearchVO = new ErrorSearchVO();
			List<AuditServiceVO> errorListForSearch = new ArrayList<AuditServiceVO>();

			AuditServiceVO errorService = null;
			for (AuditServiceVO service : searchResponse.getAuditServiceVOs()) {
				errorService = new AuditServiceVO();
				errorService.setServiceName(service.getServiceName());
				if (service.getTransactionVOs() != null) {
					List<AuditTransactionVO> errortransactionVOs = new ArrayList<AuditTransactionVO>();
					for (AuditTransactionVO transaction : service.getTransactionVOs()) {
						errortransactionVOs.add(transaction);
					}
					errorService.setTransactionVOs(errortransactionVOs);
					errorListForSearch.add(errorService);
				}
			}

			rqErrorSearchVO.setAuditServiceVOs(errorListForSearch);
			rqErrorSearchVO.setFromDate(fromDate);

			// call error service
			ErrorResponseVO errorResponse = callErrorSearchService(rqErrorSearchVO);

			// send mail/write to log file
			try {
				FileWriter writer = new FileWriter("AuditLog.txt", true);
				if (searchResponse != null || errorResponse != null) {
					StringBuilder report = constructAlertReport(searchResponse, errorResponse);
					writer.write(report.toString()); // write new line
					//AlertMail.generateMailAlert(alertReport.toString());
				}
				writer.close();
			} catch (IOException e) {
				System.out.println("Exception while writing into file : " + e.getMessage());
			}

			// check if interval needs to update
			Calendar currentTime = Calendar.getInstance();
			int returnInterval = getInterval();
			if (returnInterval != currentInterval) {
				startSchedular();
			}
			if (currentTime.getTime().after(endBuffer)) {
				startSchedular();
			}
		}

	}

	private StringBuilder constructAlertReport(AuditResponseVO searchResponse, ErrorResponseVO errorResponse) {
		StringBuilder alertReport = new StringBuilder();
		for (AuditServiceVO res : searchResponse.getAuditServiceVOs()) {
			if (res.getTransactionVOs() != null && !res.getTransactionVOs().isEmpty()) {
				alertReport.append(new Date().toString());
				for (AuditTransactionVO transaction : res.getTransactionVOs()) {
					if (transaction.isAuditStatus() != true) {
						alertReport.append(res.getServiceName());
						alertReport.append(" :: ");
						alertReport.append(transaction.getTransactionName());
						alertReport.append(" :: ");
						alertReport.append(transaction.isAuditStatus());
						alertReport.append(" :: ");
						if (transaction.getTransactionName().equalsIgnoreCase("PAYMENT_JOB")
								|| transaction.getTransactionName().equalsIgnoreCase("RECEIPT_TRANSACTION")) {
							alertReport.append("SEVERITY: CRITICAL");
						} else {
							alertReport.append("SEVERITY: MAJOR");
						}
						alertReport.append("\r\n"); // write new line
					}
				}
			}
		}

		for (AuditServiceVO res : errorResponse.getAuditServiceVOs()) {
			if (res.getTransactionVOs() != null && !res.getTransactionVOs().isEmpty()) {
				alertReport.append(new Date().toString());
				for (AuditTransactionVO transaction : res.getTransactionVOs()) {
					if (transaction.isAuditStatus() == true) {
						alertReport.append(res.getServiceName());
						alertReport.append(" :: ");
						alertReport.append(transaction.getTransactionName());
						alertReport.append(" :: ");
						alertReport.append("ERROR");
						alertReport.append(" :: ");
						alertReport.append("SEVERITY: CRITICAL");
						alertReport.append("\r\n"); // write new line
					}
				}
			}
		}
		return alertReport;
	}

	private int getInterval() {
		int interval = 0;
		Calendar current = Calendar.getInstance();
		int currentTime = current.get(Calendar.HOUR_OF_DAY);
		for (Entry<String, Integer> entry : repeatInterval.entrySet()) {
			if (!entry.getKey().equals("DEFAULT")) {
				String[] rangeBoundary = entry.getKey().split("-");
				String fromTime = rangeBoundary[0];
				String toTime = rangeBoundary[1];
				if (currentTime >= Integer.parseInt(fromTime) && currentTime < Integer.parseInt(toTime)) {
					interval = entry.getValue();
					break;
				}
			}
		}
		if (interval == 0) {
			interval = repeatInterval.get("DEFAULT");
		}
		System.out.println("Setting default interval");
		return interval;
	}

	public void setSchedularParameters(List<MasterAuditServiceConfgVO> monitorServices,
			MasterAuditMonitorWorkingConfgVO auditWorkingConfgVO, Map<String, Integer> intervalMap) {

		System.out.println("Setting parameters");
		this.monitorServices = monitorServices;
		this.startHour = auditWorkingConfgVO.getStartHour();
		this.startMinute = auditWorkingConfgVO.getStartMinute();
		this.endHour = auditWorkingConfgVO.getEndHour();
		this.endMinute = auditWorkingConfgVO.getEndMinute();
		this.repeatInterval = intervalMap;

		Calendar storeOperation = Calendar.getInstance();
		storeOperation.set(Calendar.HOUR_OF_DAY, startHour);
		storeOperation.set(Calendar.MINUTE, startMinute);
		long t = storeOperation.getTimeInMillis();
		startBuffer = new Date(t + (auditWorkingConfgVO.getStartAlertBuffer() * ONE_MINUTE_IN_MILLIS));

		storeOperation.set(Calendar.HOUR_OF_DAY, endHour);
		storeOperation.set(Calendar.MINUTE, endMinute);
		t = storeOperation.getTimeInMillis();
		endBuffer = new Date(t + (auditWorkingConfgVO.getEndAlertBuffer() * ONE_MINUTE_IN_MILLIS));

		System.out.println(startBuffer);
		System.out.println(endBuffer);

	}

	public void startSchedular() {

		Boolean always = false;
		Boolean dayEnd = false;
		Calendar today = Calendar.getInstance();

		serviceListForSearch.clear();

		Calendar endTimeCal = Calendar.getInstance();
		endTimeCal.set(Calendar.HOUR_OF_DAY, this.endHour);
		endTimeCal.set(Calendar.MINUTE, this.endMinute);

		if (monitorServices != null) {
			for (MasterAuditServiceConfgVO serviceVo : monitorServices) {

				AuditServiceVO searchServiceVO = new AuditServiceVO();
				searchServiceVO.setServiceName(serviceVo.getServiceName());
				List<MasterAuditTransactionConfgVO> transactionNames = serviceVo.getTransactionNames();
				List<AuditTransactionVO> searchTransactions = new ArrayList<AuditTransactionVO>();

				if (transactionNames != null) {
					for (MasterAuditTransactionConfgVO transaction : transactionNames) {
						if (transaction.getMonitorPattern().equalsIgnoreCase("DAY_START")
								&& today.getTime().before(startBuffer)) {
							today.setTime(startBuffer);
							AuditTransactionVO transactionVo = new AuditTransactionVO();
							transactionVo.setTransactionName(transaction.getTransactionName());
							searchTransactions.add(transactionVo);
							always = false;
						} else if (transaction.getMonitorPattern().equalsIgnoreCase("ALWAYS")
								&& today.getTime().after(startBuffer) && today.getTime().before(endBuffer)) {
							today.setTime(startBuffer);
							always = true;
							AuditTransactionVO transactionVo = new AuditTransactionVO();
							transactionVo.setTransactionName(transaction.getTransactionName());
							searchTransactions.add(transactionVo);
						} else if (transaction.getMonitorPattern().equalsIgnoreCase("DAY_END")
								&& today.getTime().before(endBuffer) && today.getTime().after(endTimeCal.getTime())) {
							today.setTime(endTimeCal.getTime());
							AuditTransactionVO transactionVo = new AuditTransactionVO();
							transactionVo.setTransactionName(transaction.getTransactionName());
							searchTransactions.add(transactionVo);
							always = false;
						}
					}
					searchServiceVO.setTransactionVOs(searchTransactions);
					serviceListForSearch.add(searchServiceVO);
				}

				if (today.getTime().after(endBuffer)) {
					dayEnd = true;
				}

				if (!dayEnd) {
					if (always) {
						System.out.println("Starting repeat timer...");
						timer.cancel();
						timer = new Timer();
						MyTimeTask timerTask = new MyTimeTask();
						int interval = getInterval();
						currentInterval = interval;
						timer.schedule(timerTask, today.getTime(), interval * ONE_MINUTE_IN_MILLIS);
					} else {
						System.out.println("Starting non-repeat timer...");
						timer.cancel();
						timer = new Timer();
						MyTimeTask timerTask = new MyTimeTask();
						timer.schedule(timerTask, today.getTime());
					}
				} else {
					timer.cancel();
				}
			}
		}
	}

	private AuditResponseVO callSearchService(AuditSearchVO searchVO) {
		AuditResponseVO responseVO = null;
		try {
			WebClient client = WebClient.create(SERVICE_HOST);
			client.path("audit-manager/services/audit-data/searchAudit");
			client.type("application/xml").accept("application/xml");
			responseVO = client.post(searchVO, AuditResponseVO.class);
		} catch (Exception e) {
			System.out.println("Exception while executing Audit search service: " + e.getMessage());
		}
		return responseVO;
	}

	private ErrorResponseVO callErrorSearchService(ErrorSearchVO searchVO) {
		ErrorResponseVO responseVO = null;
		try {
			WebClient client = WebClient.create(SERVICE_HOST);
			client.path("error-manager/services/error-data/searchError");
			client.type("application/xml").accept("application/xml");
			responseVO = client.post(searchVO, ErrorResponseVO.class);
		} catch (Exception e) {
			System.out.println("Exception while executing Error search service: " + e.getMessage());
		}
		return responseVO;
	}

}
