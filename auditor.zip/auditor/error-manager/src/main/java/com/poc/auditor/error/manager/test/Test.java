package com.poc.auditor.error.manager.test;

import java.io.BufferedWriter;
import java.io.FileWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.poc.auditor.error.manager.dto.ErrorRequestVO;

public class Test {

	public static void main(String[] args) {

		try {
			ErrorRequestVO auditRequestVO = new ErrorRequestVO();
			auditRequestVO.setTenantId("Tenant1");
			auditRequestVO.setOperationName("PAYMENT_JOB");
			auditRequestVO.setSourceSystem("BOOKING");
			auditRequestVO.setTargetSystem("UDI");
			auditRequestVO.setReqPayload("request");
			JAXBContext context;
			BufferedWriter writer = null;
			writer = new BufferedWriter(new FileWriter("error-request.xml"));
			context = JAXBContext.newInstance(ErrorRequestVO.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(auditRequestVO, writer);
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
