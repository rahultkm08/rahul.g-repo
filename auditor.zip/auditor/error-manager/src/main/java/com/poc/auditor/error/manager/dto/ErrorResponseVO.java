package com.poc.auditor.error.manager.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ErrorResponseVO")
@XmlRootElement(name = "ErrorResponseVO")
public class ErrorResponseVO {


	@XmlElement(name = "Status", required = true)
	private Boolean status;

	private List<AuditServiceVO> auditServiceVOs;

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public List<AuditServiceVO> getAuditServiceVOs() {
		return auditServiceVOs;
	}

	public void setAuditServiceVOs(List<AuditServiceVO> auditServiceVOs) {
		this.auditServiceVOs = auditServiceVOs;
	}
	
}
