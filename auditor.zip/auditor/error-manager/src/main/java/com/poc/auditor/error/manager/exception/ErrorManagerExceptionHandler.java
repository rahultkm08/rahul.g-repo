package com.poc.auditor.error.manager.exception;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Handler class for managing Exception on Error-Service API.
 */
@Provider
public final class ErrorManagerExceptionHandler implements ExceptionMapper<ErrorManagerException> {

	public Response toResponse(final ErrorManagerException exception) {
		return Response.status(Status.SERVICE_UNAVAILABLE).entity(new ErrorMessage(exception.getMessage()))
				.type(MediaType.APPLICATION_XML).build();
	}

}
