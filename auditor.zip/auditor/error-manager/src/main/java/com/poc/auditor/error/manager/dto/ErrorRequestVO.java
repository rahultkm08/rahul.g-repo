package com.poc.auditor.error.manager.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ErrorRequestVO")
@XmlRootElement(name = "ErrorRequestVO")
public class ErrorRequestVO {

	@XmlElement(name = "TenantId", required = true)
	private String tenantId;
	
	@XmlElement(name = "Operation", required = true)
	private String operationName;

	@XmlElement(name = "SourceSystem", required = true)
	private String sourceSystem;

	@XmlElement(name = "TargetSystem", required = true)
	private String targetSystem;
	
	@XmlElement(name = "ReqPayload", required = true)
	private String reqPayload;
	
	@XmlElement(name = "ErrPayload", required = true)
	private String errPayload;
	
	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTargetSystem() {
		return targetSystem;
	}

	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}

	public String getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}

	public String getErrPayload() {
		return errPayload;
	}

	public void setErrPayload(String errPayload) {
		this.errPayload = errPayload;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
