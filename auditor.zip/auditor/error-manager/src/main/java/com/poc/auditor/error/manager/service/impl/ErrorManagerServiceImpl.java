package com.poc.auditor.error.manager.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.poc.auditor.error.manager.component.ErrorManagerComponent;
import com.poc.auditor.error.manager.dto.ErrorRequestVO;
import com.poc.auditor.error.manager.dto.ErrorResponseVO;
import com.poc.auditor.error.manager.dto.ErrorSearchVO;
import com.poc.auditor.error.manager.exception.ErrorManagerException;
import com.poc.auditor.error.manager.service.ErrorManagerService;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for managing Error Data operations.
 */
public class ErrorManagerServiceImpl implements ErrorManagerService {

	@Autowired
	private ErrorManagerComponent errorManagerComponent;
	
	public ErrorManagerComponent getErrorManagerComponent() {
		return errorManagerComponent;
	}

	public void setErrorManagerComponent(ErrorManagerComponent errorManagerComponent) {
		this.errorManagerComponent = errorManagerComponent;
	}

	public ErrorResponseVO saveErrorEntry(ErrorRequestVO requestVO) throws ErrorManagerException {
		ErrorResponseVO responseVO = new ErrorResponseVO();
		responseVO.setStatus(errorManagerComponent.saveErrorEntry(requestVO));
		return responseVO;
	}

	public ErrorResponseVO searchErrorEntry(ErrorSearchVO requestVO) throws ErrorManagerException {
		return errorManagerComponent.searchErrorEntry(requestVO);
	}

}
