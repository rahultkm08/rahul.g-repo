package com.poc.auditor.error.manager.dao.impl;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.poc.auditor.error.manager.dao.ErrorManagerDAO;
import com.poc.auditor.error.manager.dao.entity.ErrorData;
import com.poc.auditor.error.manager.dto.AuditServiceVO;
import com.poc.auditor.error.manager.dto.AuditTransactionVO;
import com.poc.auditor.error.manager.dto.ErrorRequestVO;
import com.poc.auditor.error.manager.dto.ErrorResponseVO;
import com.poc.auditor.error.manager.dto.ErrorSearchVO;
import com.poc.auditor.error.manager.exception.ErrorManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * DAO Class for managing Error Data operations.
 */
@Repository
public class ErrorManagerDAOImpl implements ErrorManagerDAO {

	/**
	 * logger.
	 */
	final static Logger logger = Logger.getLogger(ErrorManagerDAOImpl.class);
	
	protected EntityManager entityManager;
	
	private static String GET_ERROR_DATA = "SELECT COUNT(err) FROM ErrorData err WHERE err.sourceSystem =:sourceSystem AND err.operationName =:operationName"
			+ " AND err.createdDate BETWEEN :startDate AND :endDate";
	
	@Autowired
	private Mapper dozerMapper;
	 
    public EntityManager getEntityManager() {
        return entityManager;
    }
    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

	@Transactional
	public Boolean saveErrorEntry(ErrorRequestVO requestVO) throws ErrorManagerException {
		Boolean status;
		try {
			ErrorData errorEntity = dozerMapper.map(requestVO, ErrorData.class);
			errorEntity.setCreatedBy(System.getProperty("user.name"));
			errorEntity.setCreatedDate(new Date());
			getEntityManager().persist(errorEntity);
			if (requestVO.getErrPayload() != null
					&& requestVO.getErrPayload().contains("Failed to connect to remote HTTP service")) {
				alertError(requestVO);
			}
			status = true;
		} catch (Exception e) {
			status = false;
			logger.error("Unable to save Error : " + requestVO.getTenantId() + " : " + requestVO.getSourceSystem()
					+ " : " + requestVO.getTargetSystem());
			throw new ErrorManagerException("Unable to save Error now, please try again", e);
		}
		return status;
	}
    
	private void alertError(ErrorRequestVO requestVO) {
		StringBuilder alertReport = new StringBuilder();
		alertReport.append(new Date().toString());
		alertReport.append(requestVO.getSourceSystem());
		alertReport.append(" :: ");
		alertReport.append(requestVO.getOperationName());
		alertReport.append(" :: ");
		alertReport.append("ERROR");
		alertReport.append(" :: ");
		alertReport.append("SEVERITY: CRITICAL");
		alertReport.append(" :: ");
		alertReport.append(requestVO.getTargetSystem() + " DOWN");
		alertReport.append("\r\n");
		try {
			FileWriter writer = new FileWriter("ErrorLog-Critical.txt", true);
			writer.write(alertReport.toString()); // write new line
			//AlertMail.generateMailAlert(alertReport.toString());
			writer.close();
		} catch (IOException e) {
			logger.error("Exception while writing into file : " + e.getMessage());
		}
	}
	
	@Transactional
	public ErrorResponseVO searchErrorEntry(ErrorSearchVO searchVO) throws ErrorManagerException {
		ErrorResponseVO errorResponseVO = new ErrorResponseVO();
		try {
			errorResponseVO.setAuditServiceVOs(searchVO.getAuditServiceVOs());
			Long recordCount = (long) 0;
			Query q1 = getEntityManager().createQuery(GET_ERROR_DATA);
			q1.setParameter("startDate", searchVO.getFromDate(), TemporalType.TIMESTAMP);
			q1.setParameter("endDate", searchVO.getToDate(), TemporalType.TIMESTAMP);
			for (AuditServiceVO auditServiceVO : errorResponseVO.getAuditServiceVOs()) {
				q1.setParameter("sourceSystem", auditServiceVO.getServiceName());
				for (AuditTransactionVO auditTransactionVO : auditServiceVO.getTransactionVOs()) {
					q1.setParameter("operationName", auditTransactionVO.getTransactionName());
					recordCount = (Long) q1.getSingleResult();
					System.out.println(recordCount);
					if (recordCount > 0) {
						auditTransactionVO.setAuditStatus(true);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Unable to search Error");
			throw new ErrorManagerException("Unable to search Error", e);
		}
		return errorResponseVO;
	}

}
