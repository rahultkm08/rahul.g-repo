package com.poc.auditor.error.manager.exception;

import java.io.Serializable;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Exception class for managing Error-Service API errors.
 */
public class ErrorManagerException extends Exception implements Serializable {

	private static final long serialVersionUID = -4873736688422645862L;

	public ErrorManagerException() {
		super();
	}

	public ErrorManagerException(String msg) {
		super(msg);
	}

	public ErrorManagerException(String msg, Exception e) {
		super(msg, e);
	}
}
