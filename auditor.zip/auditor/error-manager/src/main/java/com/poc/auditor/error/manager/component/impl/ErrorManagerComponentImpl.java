package com.poc.auditor.error.manager.component.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.poc.auditor.error.manager.component.ErrorManagerComponent;
import com.poc.auditor.error.manager.dao.ErrorManagerDAO;
import com.poc.auditor.error.manager.dto.ErrorRequestVO;
import com.poc.auditor.error.manager.dto.ErrorResponseVO;
import com.poc.auditor.error.manager.dto.ErrorSearchVO;
import com.poc.auditor.error.manager.exception.ErrorManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Component class for managing Error Data operations.
 */
@Component
public class ErrorManagerComponentImpl implements ErrorManagerComponent {

	@Autowired
	private ErrorManagerDAO errorManagerDAO;

	public ErrorManagerDAO getErrorManagerDAO() {
		return errorManagerDAO;
	}

	public void setErrorManagerDAO(ErrorManagerDAO errorManagerDAO) {
		this.errorManagerDAO = errorManagerDAO;
	}

	public Boolean saveErrorEntry(ErrorRequestVO requestVO) throws ErrorManagerException {
		Boolean status = errorManagerDAO.saveErrorEntry(requestVO);
		return status;
	}

	public ErrorResponseVO searchErrorEntry(ErrorSearchVO searchVO) throws ErrorManagerException {
		ErrorResponseVO responseVO = new ErrorResponseVO();
		if (searchVO != null && searchVO.getFromDate() != null
				&& searchVO.getAuditServiceVOs() != null
				&& !searchVO.getAuditServiceVOs().isEmpty()) {
			responseVO = errorManagerDAO.searchErrorEntry(searchVO);
			responseVO.setStatus(true);
		} else {
			responseVO.setStatus(false);
		}
		return responseVO;
	}

}
