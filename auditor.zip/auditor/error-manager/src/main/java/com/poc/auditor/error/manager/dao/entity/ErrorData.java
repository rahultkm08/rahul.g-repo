package com.poc.auditor.error.manager.dao.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Entity to save Error Data.
 */
@Entity
@Table(name = "AUDT_ERROR_MNGR")
@NamedQueries(value = { @NamedQuery(name = "selectAllError", query = "SELECT err FROM ErrorData err WHERE err.sourceSystem = :sourceSystem") })
public class ErrorData {

	private Integer errorId;
	
	private String tenantId;

	private String operationName;

	private String sourceSystem;

	private String targetSystem;
	
	private String reqPayload;
	
	private String errPayload;

	private String createdBy;

	private Date createdDate;
	
	@Id
	@SequenceGenerator(name = "errorIdSeq", allocationSize = 1, initialValue = 1)
	@Column(name = "ERROR_ID", unique = true, nullable = false, insertable = true, updatable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getErrorId() {
		return errorId;
	}

	public void setErrorId(Integer errorId) {
		this.errorId = errorId;
	}

	@Column(name = "TENANT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 45)
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	@Column(name = "OPERATION_NAME", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	
	@Column(name = "SOURCE_SYSTEM", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Column(name = "TARGET_SYSTEM", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getTargetSystem() {
		return targetSystem;
	}

	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}

	@Column(name = "CREATED_BY", unique = false, nullable = false, insertable = true, updatable = false, length = 10)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE", unique = false, nullable = false, insertable = true, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "REQ_PAYLOAD", unique = false, nullable = false, insertable = true, updatable = false)
	public String getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}

	@Column(name = "ERROR_PAYLOAD", unique = false, nullable = false, insertable = true, updatable = false)
	public String getErrPayload() {
		return errPayload;
	}

	public void setErrPayload(String errPayload) {
		this.errPayload = errPayload;
	}
	
}
