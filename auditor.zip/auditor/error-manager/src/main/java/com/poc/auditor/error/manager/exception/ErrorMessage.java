package com.poc.auditor.error.manager.exception;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * Class to store the error message on Exception in Error-Service API.
 */
public class ErrorMessage {
	
	private String error;

	public ErrorMessage(String error) {
		this.error = error;
	}

	public String getError() {
		return error;
	}
}
