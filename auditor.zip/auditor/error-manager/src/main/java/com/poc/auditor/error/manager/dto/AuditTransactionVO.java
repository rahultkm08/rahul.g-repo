package com.poc.auditor.error.manager.dto;

public class AuditTransactionVO {

	private String transactionName;
	
	private boolean auditStatus;
	
	private String errorPayload;

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public boolean isAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(boolean auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getErrorPayload() {
		return errorPayload;
	}

	public void setErrorPayload(String errorPayload) {
		this.errorPayload = errorPayload;
	}
	
}
