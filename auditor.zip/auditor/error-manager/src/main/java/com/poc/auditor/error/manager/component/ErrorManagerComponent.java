package com.poc.auditor.error.manager.component;

import com.poc.auditor.error.manager.dto.ErrorRequestVO;
import com.poc.auditor.error.manager.dto.ErrorResponseVO;
import com.poc.auditor.error.manager.dto.ErrorSearchVO;
import com.poc.auditor.error.manager.exception.ErrorManagerException;

public interface ErrorManagerComponent {

	public Boolean saveErrorEntry(ErrorRequestVO requestVO) throws ErrorManagerException;

	public ErrorResponseVO searchErrorEntry(ErrorSearchVO requestVO) throws ErrorManagerException;
}
