package com.poc.auditor.error.manager.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import com.poc.auditor.error.manager.dto.ErrorRequestVO;
import com.poc.auditor.error.manager.dto.ErrorResponseVO;
import com.poc.auditor.error.manager.dto.ErrorSearchVO;
import com.poc.auditor.error.manager.exception.ErrorManagerException;

/**
 * 
 * @author Rahul GopalakrishnaPillai
 * 
 * CXF Rest API for managing Error Data operations.
 */
@Component
@Path("/error-data")
public interface ErrorManagerService {

	@POST
	@Path("/saveError")
	@Consumes({MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_XML})
	public ErrorResponseVO saveErrorEntry(ErrorRequestVO requestVO) throws ErrorManagerException;
	
	@POST
	@Path("/searchError")
	@Consumes({MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_XML})
	public ErrorResponseVO searchErrorEntry(ErrorSearchVO requestVO) throws ErrorManagerException;
}

