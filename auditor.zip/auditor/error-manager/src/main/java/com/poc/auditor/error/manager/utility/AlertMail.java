package com.poc.auditor.error.manager.utility;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class AlertMail {
	/**
	 * logger.
	 */
	final static Logger logger = Logger.getLogger(AlertMail.class);
	
	public static void generateMailAlert(String body) {

		String host = "alt1.aspmx.l.google.com";
		final String user = "rahultkm08@gmail.com";
		String to = "rahultkm08@gmail.com";

		// Get the session object
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.auth", "false");

		Session session = Session.getDefaultInstance(props, null);
		session.setDebug(true);

		// Compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.saveChanges();
			message.setFrom(new InternetAddress(user));
			// message.addRecipient(Message.RecipientType.TO,new
			// InternetAddress(to));
			message.addRecipients(Message.RecipientType.TO, to);
			message.setSubject("Service Monitoring");
			//message.setText("This is test mail for Monitoring.");
			message.setText(body);
			// send the message
			Transport.send(message);
		} catch (MessagingException e) {
			logger.error("Unable to send Service Monitoring mail");
		}
	}
}